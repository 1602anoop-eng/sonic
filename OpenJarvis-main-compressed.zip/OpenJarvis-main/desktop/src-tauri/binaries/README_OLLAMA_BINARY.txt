The 77 MB file "ollama-aarch64-apple-darwin" was removed only to make this zip smaller.
It is a third-party Ollama binary, not OpenJarvis source code.
To get it back, run from the project root:
  bash frontend/src-tauri/scripts/download-ollama.sh aarch64-apple-darwin
Then copy/move the downloaded file into desktop/src-tauri/binaries/ if you need it there.
